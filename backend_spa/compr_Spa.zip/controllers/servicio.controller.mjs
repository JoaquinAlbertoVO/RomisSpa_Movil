import * as service from "../services/servicio.service.mjs";
import { servicioSchema } from "../validators/servicio.schema.mjs";
import { ok, created, noContent, badRequest, notFound } from "../utils/response.mjs";

export const insertarServicio = async (event) => {
  const body = JSON.parse(event.body);
  const parsed = servicioSchema.safeParse(body);

  if (!parsed.success) return badRequest(parsed.error);

  const servicio = await service.insertar(parsed.data);
  return created(servicio);
};
export const buscarServicio = async (nombre) => {
  const servicio = await service.getById(nombre);
  if (!servicio) return notFound("Servicio no encontrado");
  return ok(servicio);
};

export const actualizarServicio = async (nombre, event) => {
  const body = JSON.parse(event.body);
  const servicio = await service.actualizar(nombre, body);
  return ok(servicio);
};
  
export const eliminarServicio = async (nombre) => {
  await service.eliminar(nombre);
  return noContent();
};

export const cargarServicios = async (query) => {
  const limit = query?.limit ? parseInt(query.limit) : 10;
  const result = await service.listado(limit, query?.lastKey);
  return ok(result);
};