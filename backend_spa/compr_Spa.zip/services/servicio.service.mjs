import * as repo from "../repositories/servicio.repository.mjs";

export const insertar = async (data) => {

  await repo.insertarServicio(data);
  return data;
};

export const getById = async (nombre) => {
  const result = await repo.getServicioByNombre(nombre);
  return result.Item;
};


export const eliminar = async (nombre) => {
  await repo.eliminarServicio(nombre);
};


export const actualizar = async (nombre, body) => {
    let updateExpression = "set ";
    let names = {};
    let values = {};
  
    const filteredBody = { ...body };
    delete filteredBody.nombre;
  
    // Aseguramos que si viene 'precio', se envíe como número puro a DynamoDB
    if (filteredBody.precio !== undefined) {
      filteredBody.precio = Number(filteredBody.precio);
    }
  
    const keys = Object.keys(filteredBody);
  
    keys.forEach((key, index) => {
      updateExpression += `#${key} = :${key}`;
      if (index < keys.length - 1) updateExpression += ", ";
      names[`#${key}`] = key;
      values[`:${key}`] = filteredBody[key];
    });
  
    // Ejecuta la actualización dinámica en tu repositorio
    await repo.actualizarServicio(nombre, updateExpression, names, values);
    
    // 🔥 CORREGIDO: Retornamos el objeto actualizado armado para garantizar que el controlador envíe la data limpia
    return { nombre, ...filteredBody };
  };